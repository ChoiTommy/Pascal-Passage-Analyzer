========================================================================

*Grandmaly - a simple composition analyzer*

========================================================================

Run: put your text file in the same folder, set your console to 120*30 
and run the main.exe.

------------------------------------------------------------------------

File: use your own file or use the default 'default.txt' or 'test.txt'
The 'ASCII art text files' folder must be put together with the main.exe

------------------------------------------------------------------------

How to use:

You can only use a keyboard to control the program. Basically using 
arrow keys, enter key, escape key and the page up and down key can 
fully transit to different parts of the program.

First, type your file path and select the appropriate button by using 
the left and right arrow key, then click enter key to analyze the 
composition.

Second, select the function you want to use by clicking the up and down 
arrow key, then click enter.

Third, to return to main screen at any other screens, simply click the 
escape key.

------------------------------------------------------------------------

(c) Tommy Choi 2020
6A06 HKTA Tang Hin Memorial Secondary School